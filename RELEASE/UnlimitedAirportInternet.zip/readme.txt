Unlimited Airport Internet - v1.0 - (c) Elias Bachaalany <lallousz-x86@yahoo.com>

This is a C# shell for the Batchography script "ChangeMACAddressBatch.bat"

For more information:

- Help and download: http://lallouslab.net/2016/06/27/unlimited-internet-at-airports/
- Batchography book: http://lallouslab.net/2016/05/10/batchography/
- ChangeMACAddress : http://lallouslab.net/2016/06/20/batchography-change-mac-address-batch-script/
- lallouslab:        http://lallouslab.net
